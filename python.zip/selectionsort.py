list1 = [4,5,6,7,2]
print("unsorted list",list1)
for i in range(len(list1)-1):
    min_val = min(list[i:])
print(list1)

