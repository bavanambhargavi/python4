import array as np
num1 = int(input("number1:"))
num2 = int(input("number2:"))
lower = int(input("lower limit:"))
upper = int(input("upper limit"))
for i in range(lower,upper+1):
    if  np (num1,i) ==1:
        print(i)




