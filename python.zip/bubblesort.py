list1 = [10,3,4,5]
for j in range(len(list1)-1,0,-1):
    for i in range(j):
        if list1[i] ==  list[i+1]:
            list1[i],list[i+1] = list[i+1],list1[i]
            print(list1)

        else:
            print(list1)
            print()

print("sorted list:",list1)