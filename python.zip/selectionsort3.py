List1 = [34,5,6,81,0,5]

 for i in range (len(List1)-1):
    min_val = min(list[i:])

if List1==  List1[min_
    print(List1)

print ("unsorted List", List1)


